import React from 'react';

const NavBrand = ({brandName}) => {
  return (
    <div className='NavBrand'>
      {brandName}
    </div>
  );
};

export default  NavBrand;
