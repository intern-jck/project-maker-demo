import React, {useState, useEffect} from 'react';
import {GiHamburgerMenu, GoX} from 'react-icons/gi';

const NavMenu = () => {
  return (
    <div className='NavMenu'>
      <ul>
        <li>
          PROJECT HERE
        </li>
      </ul>
    </div>
  );
};

export default NavMenu;
